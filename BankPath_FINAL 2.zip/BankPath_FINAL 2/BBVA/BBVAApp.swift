
import SwiftUI

@main
struct BBVAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

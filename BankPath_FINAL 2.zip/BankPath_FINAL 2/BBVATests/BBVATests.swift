//
//  BBVATests.swift
//  BBVATests
//
//  Created by iOS Lab on 12/05/25.
//

import Testing
@testable import BBVA

struct BBVATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
